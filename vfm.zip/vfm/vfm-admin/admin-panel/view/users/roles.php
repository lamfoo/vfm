<?php
$getroles = array(
    'editor',
   	'contributor',
);
