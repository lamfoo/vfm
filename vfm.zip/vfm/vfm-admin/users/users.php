<?php

 $_USERS = array (
  0 => 
  array (
    'name' => 'admin',
    'pass' => '$1$Yyyw8K1z$IamkIYITKkroSQhWLvl490',
    'role' => 'superadmin',
    'email' => 'foolam77@gmail.com',
  ),
  1 => 
  array (
    'name' => 'Pascoal',
    'pass' => '$1$RG3goVg4$N8r1oC1C2hqoRtX/3/Uws1',
    'role' => 'user',
    'disabled' => false,
    'email' => 'joaqeno@gmail.com',
  ),
  2 => 
  array (
    'name' => 'Leonel',
    'pass' => '$1$VAyQrMG6$rIq8ihhVQe.a3C4xEwm0t1',
    'role' => 'user',
    'email' => 'leonel@gmail.com',
  ),
);
